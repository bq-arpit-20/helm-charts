---
name: Question
about: Questions should be asked on https://discuss.elastic.co/
---

Hey, stop right there!

We use GitHub to track feature requests and bug reports. Please do not submit issues for questions about how to use features of these helm charts, best practices, or development related help.

However, we do want to help! Head on over to our official forums and ask your questions there. In additional to awesome, knowledgeable community contributors, core helm chart developers are on the forums every single day to help you out.

The forums are here: https://discuss.elastic.co/

We can't stop you from opening an issue here, but it will likely linger without a response for days or weeks before it is closed and we ask you to join us on the forums instead. Save yourself the time, and ask on the forums today.
