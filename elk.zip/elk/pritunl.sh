#!/bin/bash
GIT_ROOT=`git rev-parse --show-toplevel`

# Name of environment variables file in service folder(in key=value syntax)
ENV=$1
INFRA_ID="hcnuefikw6xiq7ui"
PROD_ID="iiyonqgbeymu3oca"
STAGING_ID="sj79t4tanhfbysrx"
DEFAULT_NS="logging"

# checkDependancy() 
# {
#     counter=0
#     for name in pritunl-client
#     do
#         type $name &>/dev/null || { echo -en "$name is not installed. Installing it now...........'\n";counter=1; }
#         if [ ${counter} = 1 ]; then
#             sudo apt install pritunl-client-electron
#             echo "adding client 1"
#             pritunl-client add https://vpn.prod.poipt.net/k/hH7w4SZc
#             echo "adding client 2"
#             pritunl-client add https://35.238.227.237/k/VZVjHNEe
#             echo "adding client 3"
#             pritunl-client add https://vpn.staging.proofofimpact.com/k/t3MuAkSb
#         fi
#     done
# }
# checkDependancy

connectVpn()
{
    if [ ${ENV} = 'infra' ]; then
        pritunl-client stop $STAGING_ID
        pritunl-client stop $PROD_ID
        pritunl-client start $INFRA_ID -p 123456
        echo "Changing the GKE cluster to $ENV"
        sleep 4
        gcloud container clusters get-credentials k8s-cluster-infra-proof --region us-central1 --project infra-350513
        k config set-context --current --namespace=$DEFAULT_NS
        sleep 3
    elif [ ${ENV} = 'staging' ]; then
        pritunl-client stop $INFRA_ID
        pritunl-client stop $PROD_ID
        pritunl-client start $STAGING_ID -p 123456
        echo "Changing the GKE cluster to $ENV"
        sleep 4
        gcloud container clusters get-credentials k8s-cluster-staging-poi --region us-central1 --project proof-of-impact
        k config set-context --current --namespace=$DEFAULT_NS
        sleep 3
    elif [ ${ENV} = 'prod' ]; then
        pritunl-client stop $INFRA_ID
        pritunl-client stop $STAGING_ID
        pritunl-client start $PROD_ID -p 123456
        echo "Changing the GKE cluster to $ENV"
        sleep 4
        gcloud container clusters get-credentials k8s-cluster-prod-poi --region us-central1 --project proof-of-impact 
        k config set-context --current --namespace=$DEFAULT_NS
        sleep 3         
    fi
}
connectVpn
